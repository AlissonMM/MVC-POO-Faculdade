package br.edu.fategru.model;

import java.util.ArrayList;
import java.util.List;

public class Teste {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Aluno a[] = new Aluno[3];
		a[0] = new Aluno();
		a[1] = new Aluno();
		a[2] = new Aluno();
		
		
		List<Aluno> alu = new ArrayList<Aluno>();
		
		alu.add(new Aluno());
		alu.add(new Aluno());
		alu.add(new Aluno());
	}

}
