package br.edu.fategru.dao;

import java.sql.*;
import java.util.List;
import java.util.ArrayList;


import br.edu.fategru.model.Aluno;
import br.edu.fategru.util.ConnectionFactory;

public class AlunoDAO {
	
	private Connection conn;
	private PreparedStatement ps;
	private ResultSet rs;
	private Aluno aluno;
	
	
	public AlunoDAO() throws Exception {
		// chama a classe ConnectionFactory e estabele uma conexão
		try {
			this.conn = ConnectionFactory.getConnection();
		} catch (Exception e) {
			throw new Exception("erro: \n" + e.getMessage());
		}
	}
	
	// método de salvar

	public void salvar(Aluno aluno) throws Exception {
		if (aluno == null)
			throw new Exception("O valor passado nao pode ser nulo");
		try {
			String SQL = "INSERT INTO tbAluno (ca, nome, email, dataNascimento,"
					+ "endereco,idade) values (?, ?, ?, ?, ?, ?)";
			conn = this.conn;
			ps = conn.prepareStatement(SQL);
			ps.setInt(1, aluno.getCa());
			ps.setString(2, aluno.getNome());
			ps.setString(3, aluno.getEmail());
			ps.setString(4, aluno.getDataNascimento());
			ps.setString(5, aluno.getEndereco());
			ps.setInt(6, aluno.getIdade());
			ps.executeUpdate();
		} catch (SQLException sqle) {
			throw new Exception("Erro ao inserir dados " + sqle);
		} finally {
			ConnectionFactory.closeConnection(conn, ps);
		}
	}
	
	public void atualizar(Aluno aluno) throws Exception {
		if (aluno == null)
			throw new Exception("O valor passado nao pode ser nulo");
		try {
			String SQL = "UPDATE tbAluno SET(nome=?, email=?, dataNascimento=?,"
					+ "endereco=?,idade=?) WHERE ca=?";
			conn = this.conn;
			ps = conn.prepareStatement(SQL);
			
			ps.setString(1, aluno.getNome());
			ps.setString(2, aluno.getEmail());
			ps.setString(3, aluno.getDataNascimento());
			ps.setString(4, aluno.getEndereco());
			ps.setInt(5, aluno.getIdade());
			ps.setInt(6, aluno.getCa());
			ps.executeUpdate();
		} catch (SQLException sqle) {
			throw new Exception("Erro ao alterar dados " + sqle);
		} finally {
			ConnectionFactory.closeConnection(conn, ps);
		}
	}
	
	
	public void excluir(Aluno aluno) throws Exception {
		if (aluno == null)
			throw new Exception("O valor passado nao pode ser nulo");
		try {
			String SQL = "DELETE FROM tbAluno WHERE ca=?";
			
			conn = this.conn;
			ps = conn.prepareStatement(SQL);
			
			ps.setInt(1, aluno.getCa());
			ps.executeUpdate();
		} catch (SQLException sqle) {
			throw new Exception("Erro ao excluir dados " + sqle);
		} finally {
			ConnectionFactory.closeConnection(conn, ps);
		}
	}
	
	public List listarAlunos() throws Exception {
		try {
			conn = this.conn;
			ps = conn.prepareStatement("SELECT * FROM tbalunos");
			rs = ps.executeQuery();
			List<Aluno> list = new ArrayList<Aluno>();
			while (rs.next()) {
				int ca = rs.getInt(1);
				String nome = rs.getString("nome");
				String email = rs.getString("email");
				String dataNascimento = rs.getString("dataNascimento");
				String endereco = rs.getString("endereco");
				int idade = rs.getInt("idade");
				list.add(new Aluno(ca, nome, email, dataNascimento, endereco, idade));
			}
			return list;
		} catch (SQLException sqle) {
			throw new Exception(sqle);
		} finally {
			ConnectionFactory.closeConnection(conn, ps, rs);
		}
	}

	
	public Aluno procurarAluno(int ca) throws Exception {

		try {
			String SQL = "SELECT  * FROM tbaluno WHERE ca=?";
			conn = this.conn;
			ps = conn.prepareStatement(SQL);
			ps.setInt(1, ca);
			rs = ps.executeQuery();
			if (rs.next()) {
				String nome = rs.getString("nome");
				String dataNascimento = rs.getString("dataNascimento");
				String endereco = rs.getString("endereco");
				String email = rs.getString("email");
				int ca1 = rs.getInt("ca");
				int idade = rs.getInt("idade");
				aluno = new Aluno(ca1,nome,email,dataNascimento,endereco,idade);
				
			}
			return aluno;
			
		} catch (SQLException sqle) {
			throw new Exception(sqle);
		} finally {
			ConnectionFactory.closeConnection(conn, ps, rs);
		}
		
		

	}
	
	

	


}
