package br.edu.fategru.view;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.TextArea;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import br.edu.fategru.dao.AlunoDAO;
import br.edu.fategru.model.Aluno;

public class Tela extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JLabel lblNewLabel;
	private JTextField txtCa;
	private JLabel lblNome;
	private JLabel lblEmail;
	private JLabel lblDataNascimento;
	private JLabel lblEndereo;
	private JLabel lblIdade;
	private JTextField txtNome;
	private JTextField txtEmail;
	private JTextField txtData;
	private JTextField txtEndereco;
	private JTextField txtIdade;
	private TextArea txtListar;
	private JButton btnNovo;
	private JButton btnSalvar;
	private JButton btnConsultar;
	private JButton btnAlterar;
	private JButton btnApagar;
	private JButton btnListar;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Tela frame = new Tela();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Tela() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 723, 611);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		lblNewLabel = new JLabel("CA");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblNewLabel.setBounds(248, 68, 46, 14);
		contentPane.add(lblNewLabel);
		
		txtCa = new JTextField();
		txtCa.setBounds(317, 65, 150, 29);
		contentPane.add(txtCa);
		txtCa.setColumns(10);
		
		lblNome = new JLabel("Nome");
		lblNome.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblNome.setBounds(248, 112, 46, 14);
		contentPane.add(lblNome);
		
		lblEmail = new JLabel("Email");
		lblEmail.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblEmail.setBounds(248, 153, 46, 14);
		contentPane.add(lblEmail);
		
		lblDataNascimento = new JLabel("Data Nascimento");
		lblDataNascimento.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblDataNascimento.setBounds(175, 194, 119, 14);
		contentPane.add(lblDataNascimento);
		
		lblEndereo = new JLabel("Endereço");
		lblEndereo.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblEndereo.setBounds(229, 229, 65, 14);
		contentPane.add(lblEndereo);
		
		lblIdade = new JLabel("Idade");
		lblIdade.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblIdade.setBounds(248, 265, 46, 14);
		contentPane.add(lblIdade);
		
		txtNome = new JTextField();
		txtNome.setColumns(10);
		txtNome.setBounds(317, 111, 150, 29);
		contentPane.add(txtNome);
		
		txtEmail = new JTextField();
		txtEmail.setColumns(10);
		txtEmail.setBounds(317, 152, 150, 29);
		contentPane.add(txtEmail);
		
		txtData = new JTextField();
		txtData.setColumns(10);
		txtData.setBounds(317, 193, 150, 29);
		contentPane.add(txtData);
		
		txtEndereco = new JTextField();
		txtEndereco.setColumns(10);
		txtEndereco.setBounds(317, 228, 150, 29);
		contentPane.add(txtEndereco);
		
		txtIdade = new JTextField();
		txtIdade.setColumns(10);
		txtIdade.setBounds(317, 264, 150, 29);
		contentPane.add(txtIdade);
		
		txtListar = new TextArea();
		txtListar.setBounds(101, 371, 492, 191);
		contentPane.add(txtListar);
		
		btnNovo = new JButton("Novo");
		btnNovo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				txtCa.setText(null);
				txtNome.setText(null);
				txtEndereco.setText(null);
				txtEmail.setText(null);
				txtIdade.setText(null);
				txtData.setText(null);
			}
		});
		btnNovo.setBounds(26, 322, 89, 23);
		contentPane.add(btnNovo);
		
		btnSalvar = new JButton("Salvar");
		btnSalvar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				// criei o objeto aluno
				Aluno aluno = new Aluno();
				aluno.setCa(Integer.parseInt(txtCa.getText()));
				aluno.setNome(txtNome.getText());
				aluno.setEmail(txtEmail.getText());
				aluno.setDataNascimento(txtData.getText());
				aluno.setEndereco(txtEndereco.getText());
				aluno.setIdade(Integer.parseInt(txtIdade.getText()));
				try {
					// abri o BD
					AlunoDAO dao = new AlunoDAO();
					dao.salvar(aluno);
					JOptionPane.showMessageDialog(null, "Salvo com Sucesso");
				}catch(Exception e1) {
					//JOptionPane.showMessageDialog(null,"Erro ao Gravar");
					JOptionPane.showMessageDialog(null,e1.getMessage());
				}

				
			}
		});
		btnSalvar.setBounds(136, 322, 89, 23);
		contentPane.add(btnSalvar);
		
		btnConsultar = new JButton("Consultar");
		btnConsultar.setBounds(248, 322, 89, 23);
		contentPane.add(btnConsultar);
		
		btnAlterar = new JButton("Alterar");
		btnAlterar.setBounds(359, 322, 89, 23);
		contentPane.add(btnAlterar);
		
		btnApagar = new JButton("Apagar");
		btnApagar.setBounds(472, 322, 89, 23);
		contentPane.add(btnApagar);
		
		btnListar = new JButton("Listar");
		btnListar.setBounds(574, 322, 89, 23);
		contentPane.add(btnListar);
	}
}
