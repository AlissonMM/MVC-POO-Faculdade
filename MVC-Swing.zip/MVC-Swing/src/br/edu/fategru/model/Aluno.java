package br.edu.fategru.model;
//JavaBean ou POJO
//Classes que tem getters e setters

public class Aluno {
	private int ca; 
	private String nome; 
	private String email;
	private String dataNascimento;  
	private String endereco;  
	private int idade;
	
	public Aluno(int ca, String nome, String email, String dataNascimento, String endereco, int idade) {
		super();
		this.ca = ca;
		this.nome = nome;
		this.email = email;
		this.dataNascimento = dataNascimento;
		this.endereco = endereco;
		this.idade = idade;
	}
	
	public Aluno() {
		
	}

	public int getCa() {
		return ca;
	}

	public void setCa(int ca) {
		this.ca = ca;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getDataNascimento() {
		return dataNascimento;
	}

	public void setDataNascimento(String dataNascimento) {
		this.dataNascimento = dataNascimento;
	}

	public String getEndereco() {
		return endereco;
	}

	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}

	public int getIdade() {
		return idade;
	}

	public void setIdade(int idade) {
		this.idade = idade;
	} 
	
	
	
	
}
